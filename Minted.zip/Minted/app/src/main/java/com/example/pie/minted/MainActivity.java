package com.example.pie.minted;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button disposeButton;
    private Button donateButton;
    private Button listButton;
    private Button infoButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        disposeButton = findViewById(R.id.disposeButton);
        donateButton = findViewById(R.id.donateButton);
        listButton = findViewById(R.id.listButton);
        infoButton = findViewById(R.id.infoButton);


        disposeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.d("Minted", "Ze dizpooze buttun haz been prezzed");
                }
        });

        donateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.d("Minted","Uz wantz to givez to ze needyz");
            }
        });

        listButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.d("Minted", "Nowz uz wantz ze fakzes pointez");
            }
        });

        infoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.d("Minted", "Are you dumb");
            }
        });



    }







}
